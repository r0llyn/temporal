package com.sc.activity;

import com.sc.dto.Deal;
import com.sc.dto.DocsResult;
import com.sc.dto.EligibilityResult;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface EligibilityActivity {
  EligibilityResult checkStpEligible(Deal deal, DocsResult docs);
}

