package com.sc.dto;

public record WorkflowResult(boolean success, String code, String message, String releaseId) {
  public static WorkflowResult ok(ReleaseResult r) { return new WorkflowResult(true, "COMPLETED", "OK", r.releaseId()); }
  public static WorkflowResult docsError(String reason) { return new WorkflowResult(false, "DOCS_ERROR", reason, null); }
  public static WorkflowResult failed(String reason) { return new WorkflowResult(false, "FAILED", reason, null); }
}