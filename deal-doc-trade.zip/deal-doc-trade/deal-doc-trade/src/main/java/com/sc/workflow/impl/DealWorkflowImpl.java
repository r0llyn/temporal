package com.sc.workflow.impl;

import com.sc.activity.*;
import com.sc.dto.*;
import com.sc.workflow.DealWorkflow;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.failure.TemporalFailure;
import io.temporal.workflow.Saga;
import io.temporal.workflow.Workflow;

import java.time.Duration;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class DealWorkflowImpl implements DealWorkflow {

  private final DealActivity deals;
  private final DocumentActivity docs;
  private final EligibilityActivity eligibility;
  private final ManualReleaseActivity manual;
  private final ReleaseActivity release;

  static <T> T step(Saga saga, Supplier<T> call, Consumer<T> compensate) {
    T out = call.get();
    saga.addCompensation(() -> compensate.accept(out));
    return out;
  }

  public DealWorkflowImpl() {
    RetryOptions commonRetry = RetryOptions.newBuilder()
        .setInitialInterval(Duration.ofSeconds(1))
        .setMaximumInterval(Duration.ofSeconds(10))
        .setMaximumAttempts(3)
        .build();

    ActivityOptions options = ActivityOptions.newBuilder()
        .setStartToCloseTimeout(Duration.ofSeconds(30))
        .setRetryOptions(commonRetry)
        .build();

    this.deals       = Workflow.newActivityStub(DealActivity.class,        options);
    this.docs        = Workflow.newActivityStub(DocumentActivity.class,    options);
    this.eligibility = Workflow.newActivityStub(EligibilityActivity.class, options);
    this.manual      = Workflow.newActivityStub(ManualReleaseActivity.class, options);
    this.release     = Workflow.newActivityStub(ReleaseActivity.class,     options);
  }

  @Override
  public WorkflowResult run(SubmitDealRequest req) {
    Saga saga = new Saga(new Saga.Options.Builder().setParallelCompensation(false).build());

    try {
      // 1) Generate Deal
      Deal deal = step(saga,
          () -> deals.generate(req),
              deals::cancelDeal);

      // 2) Process Documents
      DocsResult docsRes = step(saga,
          () -> docs.processDocuments(deal),
              docs::revertDocuments);

      // XOR #1: Documents OK?
      if (!docsRes.ok()) {
        saga.compensate();
        return WorkflowResult.docsError("Documents failed: " + docsRes.reasonIfFailed());
      }

      // 3) Check STP eligibility
      EligibilityResult elig = eligibility.checkStpEligible(deal, docsRes);

      // XOR #2: STP enabled?
      if (!elig.stpEnabled()) {
        // Manual Release path (compensatable)
        ManualReleaseResult m = step(saga,
            () -> manual.manualRelease(deal),
            x  -> manual.rollbackManualRelease(x));
      }

      // 4) Process Release (final)
      ReleaseResult rel = step(saga,
          () -> release.processRelease(deal),
              release::rollbackRelease);

      return WorkflowResult.ok(rel);

    } catch (TemporalFailure tf) {

      saga.compensate();
      return WorkflowResult.failed(tf.getMessage());

    } catch (Exception e) {

      saga.compensate();
      return WorkflowResult.failed(e.getMessage());
    }
  }
}