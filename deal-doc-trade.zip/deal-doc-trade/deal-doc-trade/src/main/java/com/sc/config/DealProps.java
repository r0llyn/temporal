package com.sc.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "temporal")
public class DealProps {

    private final Server server = new Server();
    private final Worker worker = new Worker();

    public Server getServer() {
        return server;
    }

    public Worker getWorker() {
        return worker;
    }

    public static class Server {
        /**
         * Temporal frontend gRPC target, e.g. host:port
         */
        private String target = "127.0.0.1:7233";

        /**
         * Namespace (a.k.a. Temporal namespace)
         */
        private String namespace = "default";

        public String getTarget() {
            return target;
        }

        public void setTarget(String target) {
            this.target = target;
        }

        public String getNamespace() {
            return namespace;
        }

        public void setNamespace(String namespace) {
            this.namespace = namespace;
        }
    }

    public static class Worker {
        /**
         * Task queue name this worker will poll from.
         */
        private String taskQueue = "DOC_TASK_QUEUE";

        /**
         * Max number of concurrent activity executions.
         */
        private int maxConcurrentActivityExecutionSize = 50;

        /**
         * Max number of concurrent workflow task executions.
         */
        private int maxConcurrentWorkflowTaskExecutionSize = 50;

        public String getTaskQueue() {
            return taskQueue;
        }

        public void setTaskQueue(String taskQueue) {
            this.taskQueue = taskQueue;
        }

        public int getMaxConcurrentActivityExecutionSize() {
            return maxConcurrentActivityExecutionSize;
        }

        public void setMaxConcurrentActivityExecutionSize(int maxConcurrentActivityExecutionSize) {
            this.maxConcurrentActivityExecutionSize = maxConcurrentActivityExecutionSize;
        }

        public int getMaxConcurrentWorkflowTaskExecutionSize() {
            return maxConcurrentWorkflowTaskExecutionSize;
        }

        public void setMaxConcurrentWorkflowTaskExecutionSize(int maxConcurrentWorkflowTaskExecutionSize) {
            this.maxConcurrentWorkflowTaskExecutionSize = maxConcurrentWorkflowTaskExecutionSize;
        }
    }
}
