package com.sc.dto;

public record Deal(String dealId, String customerId) {}

