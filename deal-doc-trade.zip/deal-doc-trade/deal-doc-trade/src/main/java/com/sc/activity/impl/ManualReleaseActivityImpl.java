package com.sc.activity.impl;

import com.sc.activity.ManualReleaseActivity;
import com.sc.dto.Deal;
import com.sc.dto.ManualReleaseResult;

import java.util.UUID;

public class ManualReleaseActivityImpl implements ManualReleaseActivity {

  @Override
  public ManualReleaseResult manualRelease(Deal deal) {
    // Pretend a user had to approve the release
    String ticketId = "MR-" + UUID.randomUUID();
    System.out.println("Manual release ticket created: " + ticketId + " for deal " + deal.dealId());
    return new ManualReleaseResult(ticketId);
  }

  @Override
  public void rollbackManualRelease(ManualReleaseResult manual) {
    // Pretend we close that manual release ticket
    System.out.println("Rolled back manual release ticket " + manual.ticketId());
  }
}
