package com.sc.dto;

public record ManualReleaseResult(String ticketId) {}

