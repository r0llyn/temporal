package com.sc.service;

import com.sc.config.DealProps;
import com.sc.dto.StartDealHttpResponse;
import com.sc.dto.SubmitDealRequest;
import com.sc.dto.WorkflowResult;
import com.sc.workflow.DealWorkflow;
import io.temporal.api.common.v1.WorkflowExecution;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class DealWorkflowService {

  private final WorkflowClient client;
  private final DealProps props;

  public DealWorkflowService(WorkflowClient client, DealProps props) {
    this.client = client;
    this.props = props;
  }

  private WorkflowOptions options(String workflowId) {
    return WorkflowOptions.newBuilder()
        .setTaskQueue(props.getWorker().getTaskQueue())
        .setWorkflowId(workflowId)
        .build();
  }

  public WorkflowResult runSync(SubmitDealRequest req) {
    String workflowId = "deal-" + UUID.randomUUID();
    DealWorkflow stub = client.newWorkflowStub(DealWorkflow.class, options(workflowId));
    return stub.run(req);
  }

  public StartDealHttpResponse startAsync(SubmitDealRequest req) {
    String workflowId = "deal-" + UUID.randomUUID();
    DealWorkflow stub = client.newWorkflowStub(DealWorkflow.class, options(workflowId));

    WorkflowExecution exec = WorkflowClient.start(stub::run, req);

    return new StartDealHttpResponse(exec.getWorkflowId(), exec.getRunId());
  }
}
