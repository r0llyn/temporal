package com.sc.dto;

public record EligibilityResult(boolean stpEnabled, String reason) {}

