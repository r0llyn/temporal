package com.sc.dto;

public record DealResponse(
    boolean success,
    String code,
    String message,
    String releaseId
) {
    public static DealResponse from(WorkflowResult r) {
        return new DealResponse(r.success(), r.code(), r.message(), r.releaseId());
    }
}
