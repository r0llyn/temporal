package com.sc.dto;

public record DocsResult(boolean ok, String bundleId, String reasonIfFailed) {}

