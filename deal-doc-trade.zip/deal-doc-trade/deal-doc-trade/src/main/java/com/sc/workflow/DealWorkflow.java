package com.sc.workflow;

import com.sc.dto.SubmitDealRequest;
import com.sc.dto.WorkflowResult;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface DealWorkflow {
  @WorkflowMethod
  WorkflowResult run(SubmitDealRequest request);
}
