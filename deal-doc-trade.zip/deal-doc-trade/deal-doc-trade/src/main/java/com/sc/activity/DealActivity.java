package com.sc.activity;

import com.sc.dto.Deal;
import com.sc.dto.SubmitDealRequest;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface DealActivity {
  Deal generate(SubmitDealRequest req);
  void cancelDeal(Deal deal);
}


