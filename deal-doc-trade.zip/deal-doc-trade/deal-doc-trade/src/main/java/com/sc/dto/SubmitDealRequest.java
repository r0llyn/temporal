package com.sc.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;

import java.util.List;

@Schema(name = "SubmitDealRequest", description = "Request payload to start a deal workflow")
public record SubmitDealRequest(
        @Schema(example = "STANDARD", description = "Deal type code")
        @NotBlank String dealType,

        @Schema(example = "CUST-12345", description = "Customer identifier")
        @NotBlank String customerId,

        @Schema(
                example = "[\"PROD-001\",\"PROD-002\",\"PROD-003\"]",
                description = "List of product IDs in the deal"
        )
        List<String> productIds
) {}