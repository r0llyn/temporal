package com.sc.activity.impl;

import com.sc.activity.ReleaseActivity;
import com.sc.dto.Deal;
import com.sc.dto.ReleaseResult;

import java.util.UUID;

public class ReleaseActivityImpl implements ReleaseActivity {

  @Override
  public ReleaseResult processRelease(Deal deal) {
    // Pretend we book shipment / confirm release
    String releaseId = "REL-" + UUID.randomUUID();
    System.out.println("Processed release for deal " + deal.dealId() + " -> " + releaseId);
    return new ReleaseResult(releaseId);
  }

  @Override
  public void rollbackRelease(ReleaseResult release) {
    // Pretend we cancel shipment / undo release
    System.out.println("Rolled back release " + release.releaseId());
  }
}
