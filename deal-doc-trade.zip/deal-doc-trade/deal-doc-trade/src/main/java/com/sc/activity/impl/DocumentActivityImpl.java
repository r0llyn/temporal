package com.sc.activity.impl;

import com.sc.activity.DocumentActivity;
import com.sc.dto.Deal;
import com.sc.dto.DocsResult;

public class DocumentActivityImpl implements DocumentActivity {

  @Override
  public DocsResult processDocuments(Deal deal) {
    // Simulate document validation
    if (deal.dealId().endsWith("5")) { // fake rule
      return new DocsResult(false, null, "Invalid docs for deal " + deal.dealId());
    }
    String bundleId = "BND-" + deal.dealId();
    System.out.println("Processed documents for deal " + deal.dealId());
    return new DocsResult(true, bundleId, null);
  }

  @Override
  public void revertDocuments(DocsResult docs) {
    // Pretend we delete generated docs
    if (docs.bundleId() != null) {
      System.out.println("Reverted documents bundle " + docs.bundleId());
    }
  }
}
