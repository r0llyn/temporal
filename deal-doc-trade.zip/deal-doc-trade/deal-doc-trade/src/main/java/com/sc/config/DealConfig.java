package com.sc.config;

import com.sc.activity.impl.*;
import com.sc.workflow.impl.DealWorkflowImpl;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowClientOptions;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.serviceclient.WorkflowServiceStubsOptions;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;
import io.temporal.worker.WorkerOptions;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DealConfig {

  @Bean(destroyMethod = "shutdown")
  WorkflowServiceStubs service(DealProps props) {
    return WorkflowServiceStubs.newServiceStubs(
        WorkflowServiceStubsOptions.newBuilder().setTarget(props.getServer().getTarget()).build());
  }

  @Bean
  WorkflowClient client(WorkflowServiceStubs service, DealProps props) {
    return WorkflowClient.newInstance(
        service,
        WorkflowClientOptions.newBuilder().setNamespace(props.getServer().getNamespace()).build());
  }

  // Create the factory but do NOT start it yet (we’ll start after registration).
  @Bean
  WorkerFactory workerFactory(WorkflowClient client) {
    return WorkerFactory.newInstance(client);
  }

  // Build WorkerOptions from YAML (concurrency controls).
  @Bean
  WorkerOptions workerOptions(DealProps props) {
    return WorkerOptions.newBuilder()
        .setMaxConcurrentActivityExecutionSize(
            props.getWorker().getMaxConcurrentActivityExecutionSize())
        .setMaxConcurrentWorkflowTaskExecutionSize(
            props.getWorker().getMaxConcurrentWorkflowTaskExecutionSize())
        .build();
  }

  // Create a Worker bound to your configured task queue, using the WorkerOptions above.
  @Bean
  Worker worker(WorkerFactory factory, WorkerOptions workerOptions, DealProps props) {
    return factory.newWorker(props.getWorker().getTaskQueue(), workerOptions);
  }

  @Bean
  CommandLineRunner registerAndStart(WorkerFactory factory, Worker worker) {
    return args -> {
      worker.registerWorkflowImplementationTypes(DealWorkflowImpl.class);

      worker.registerActivitiesImplementations(
          new DealActivityImpl(),
          new DocumentActivityImpl(),
          new EligibilityActivityImpl(),
          new ManualReleaseActivityImpl(),
          new ReleaseActivityImpl());

      factory.start();
    };
  }
}
