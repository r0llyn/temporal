package com.sc.activity.impl;

import com.sc.activity.DealActivity;
import com.sc.dto.Deal;
import com.sc.dto.SubmitDealRequest;
import io.temporal.failure.ApplicationFailure;

import java.util.UUID;

public class DealActivityImpl implements DealActivity {

  @Override
  public Deal generate(SubmitDealRequest req) {
    // Pretend we insert a new Deal record into DB
    String id = UUID.randomUUID().toString();
    System.out.println("Generated deal " + id + " for customer " + req.customerId());
    return new Deal(id, req.customerId());
  }

  @Override
  public void cancelDeal(Deal deal) {
    // Pretend we delete/cancel that deal from DB
    System.out.println("Cancelled deal " + deal.dealId());
  }
}
