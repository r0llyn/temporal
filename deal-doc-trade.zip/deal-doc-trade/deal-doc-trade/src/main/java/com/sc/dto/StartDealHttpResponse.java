package com.sc.dto;

public record StartDealHttpResponse(String workflowId, String runId) {}