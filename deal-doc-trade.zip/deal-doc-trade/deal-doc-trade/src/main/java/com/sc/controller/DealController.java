package com.sc.controller;

import com.sc.dto.DealResponse;
import com.sc.dto.StartDealHttpResponse;
import com.sc.dto.SubmitDealRequest;
import com.sc.dto.WorkflowResult;
import com.sc.service.DealWorkflowService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/deals")
@Tag(name = "Deals", description = "Submit deals and track workflow execution")
public class DealController {

  private final DealWorkflowService service;

  public DealController(DealWorkflowService service) {
    this.service = service;
  }

  @Operation(
      summary = "Submit Deal (sync)",
      description =
          "Starts the workflow and waits for completion. Returns the final WorkflowResult.")
  @PostMapping(
      value = "/submit",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  public DealResponse submitSync(@Validated @RequestBody SubmitDealRequest body) {
    SubmitDealRequest req =
        new SubmitDealRequest(body.dealType(), body.customerId(), body.productIds());
    WorkflowResult r = service.runSync(req);
    return new DealResponse(r.success(), r.code(), r.message(), r.releaseId());
  }

  @Operation(
      summary = "Start Deal (async)",
      description = "Starts the workflow and returns workflowId/runId immediately.")
  @PostMapping(
      value = "/start",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  public StartDealHttpResponse startAsync(@Validated @RequestBody SubmitDealRequest body) {
    SubmitDealRequest req =
        new SubmitDealRequest(body.dealType(), body.customerId(), body.productIds());
    return service.startAsync(req);
  }
}
