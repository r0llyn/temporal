package com.sc.dto;

public record ReleaseResult(String releaseId) {}