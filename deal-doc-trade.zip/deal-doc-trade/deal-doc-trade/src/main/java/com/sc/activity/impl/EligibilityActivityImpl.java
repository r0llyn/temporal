package com.sc.activity.impl;

import com.sc.activity.EligibilityActivity;
import com.sc.dto.Deal;
import com.sc.dto.DocsResult;
import com.sc.dto.EligibilityResult;

import java.util.concurrent.ThreadLocalRandom;

public class EligibilityActivityImpl implements EligibilityActivity {

  @Override
  public EligibilityResult checkStpEligible(Deal deal, DocsResult docs) {
    boolean stp = deal.customerId().length() %2 == 0;
    System.out.println("Checked STP eligibility for deal " + deal.dealId() + " => " + stp);
    return new EligibilityResult(stp, stp ? "Eligible" : "Requires manual release");
  }
}
