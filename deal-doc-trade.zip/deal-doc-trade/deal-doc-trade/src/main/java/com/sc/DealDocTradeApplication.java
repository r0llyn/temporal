package com.sc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealDocTradeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DealDocTradeApplication.class, args);
	}

}
