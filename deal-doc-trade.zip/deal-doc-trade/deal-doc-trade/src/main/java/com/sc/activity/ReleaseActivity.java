package com.sc.activity;

import com.sc.dto.Deal;
import com.sc.dto.ReleaseResult;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface ReleaseActivity {
  ReleaseResult processRelease(Deal deal);
  void rollbackRelease(ReleaseResult release);
}