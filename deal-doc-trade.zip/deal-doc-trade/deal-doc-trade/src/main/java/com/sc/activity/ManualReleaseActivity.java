package com.sc.activity;

import com.sc.dto.Deal;
import com.sc.dto.ManualReleaseResult;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface ManualReleaseActivity {
  ManualReleaseResult manualRelease(Deal deal);
  void rollbackManualRelease(ManualReleaseResult manual);
}

