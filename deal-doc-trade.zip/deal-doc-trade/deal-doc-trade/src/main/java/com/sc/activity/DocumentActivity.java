package com.sc.activity;

import com.sc.dto.Deal;
import com.sc.dto.DocsResult;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface DocumentActivity {
  DocsResult processDocuments(Deal deal);
  void revertDocuments(DocsResult docs);
}

