package com.sc.temporal.standalone;

import io.temporal.workflow.Workflow;

public class GreetingWorkflowImpl implements GreetingWorkflow {
    @Override
    public String greet(String name) {
        Workflow.getLogger(GreetingWorkflowImpl.class).info("Greeting {}", name);
        return "Hello " + name;
    }
}
