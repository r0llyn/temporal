package com.sc.temporal.standalone;

import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowClientOptions;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.serviceclient.WorkflowServiceStubsOptions;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StandaloneGreetingApp implements CommandLineRunner {

    @Value("${temporal.target}") String target;
    @Value("${temporal.namespace}") String namespace;
    @Value("${temporal.taskQueue}") String taskQueue;

    public static void main(String[] args) {
        SpringApplication.run(StandaloneGreetingApp.class, args);
    }

    @Override
    public void run(String... args) {
        WorkflowServiceStubs service = WorkflowServiceStubs.newInstance(
            WorkflowServiceStubsOptions.newBuilder().setTarget(target).build());
        WorkflowClient client = WorkflowClient.newInstance(
            service, WorkflowClientOptions.newBuilder().setNamespace(namespace).build());

        WorkerFactory factory = WorkerFactory.newInstance(client);
        Worker worker = factory.newWorker(taskQueue);
        worker.registerWorkflowImplementationTypes(GreetingWorkflowImpl.class);
        factory.start();

        System.out.println("Standalone worker up. Polling queue: " + taskQueue);
        System.out.println("Start from Temporal Web -> Type: GreetingWorkflow, Data: "Alice"");
    }
}
