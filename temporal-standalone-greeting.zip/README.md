# temporal-standalone-greeting

A **no-web** Spring Boot app that hosts a Temporal worker for a simple greeting workflow.

## Run Temporal
```bash
docker run --rm -p 7233:7233 temporalio/auto-setup:latest
```

## Build & Run
```bash
mvn spring-boot:run
```

The worker will start and poll **STANDALONE_GREETING_Q**.

## Start from Temporal Web
- Open http://localhost:8233
- **Start new workflow**
  - **Task Queue:** `STANDALONE_GREETING_Q`
  - **Workflow Type:** `GreetingWorkflow`
  - **Data:** `"Alice"` (a JSON string)
- The workflow returns: `Hello Alice`

## Notes
- Package: `com.sc.temporal.standalone`
- Java 17, Temporal SDK ${temporal.version}
