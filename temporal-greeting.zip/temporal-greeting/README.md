# Temporal Greeting (Spring Boot)

A minimal **Spring Boot + Temporal** sample that exposes a `GET /api/greet?name=Rollyn` endpoint, runs a **Temporal Workflow → Activity** to compose a message, and returns:

```json
{ "message": "Welcome Rollyn" }
```

Includes:
- Temporal Workflow/Activity, Worker, and Client configuration
- Swagger UI via springdoc at **http://localhost:8080/swagger-ui.html**
- Docker Compose to spin up a local Temporal server and UI (http://localhost:8088)

## Prereqs
- JDK 21
- Maven 3.9+
- Docker (for Temporal Server)

## Run Temporal locally
```bash
docker compose up -d
# Temporal gRPC: localhost:7233
# Temporal Web UI: http://localhost:8088
```

## Run the app
```bash
./mvnw spring-boot:run   # or: mvn spring-boot:run
# Swagger UI: http://localhost:8080/swagger-ui.html
# API:       http://localhost:8080/api/greet?name=Rollyn
```

## Notes
- The **Workflow** orchestrates logic and invokes **Activities**.
- The **Worker** is started as part of Spring context (`TemporalConfig`) and listens on task queue `GREETING_TASK_QUEUE`.
- Update `application.yml` if your Temporal target/namespace differs.
