@ECHO OFF
mvn %*
