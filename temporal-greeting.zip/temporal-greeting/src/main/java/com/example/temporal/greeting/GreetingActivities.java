package com.example.temporal.greeting;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface GreetingActivities {
    String normalizeName(String name);
    String composeGreeting(String name);
}
