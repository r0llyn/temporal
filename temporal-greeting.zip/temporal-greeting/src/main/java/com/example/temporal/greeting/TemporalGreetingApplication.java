package com.example.temporal.greeting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemporalGreetingApplication {
    public static void main(String[] args) {
        SpringApplication.run(TemporalGreetingApplication.class, args);
    }
}
