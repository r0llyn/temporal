package com.example.temporal.greeting;

import org.springframework.stereotype.Component;

@Component
public class GreetingActivitiesImpl implements GreetingActivities {

    @Override
    public String normalizeName(String name) {
        if (name == null || name.isBlank()) return "Guest";
        // Simple normalization: trim and title-case first letter
        String trimmed = name.trim();
        return trimmed.substring(0,1).toUpperCase() + trimmed.substring(1);
    }

    @Override
    public String composeGreeting(String name) {
        return "Welcome " + name;
    }
}
