package com.example.temporal.greeting;

import io.temporal.client.WorkflowClient;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.serviceclient.WorkflowServiceStubsOptions;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TemporalConfig {

    @Value("${temporal.target:127.0.0.1:7233}")
    private String target;

    @Value("${temporal.namespace:default}")
    private String namespace;

    @Value("${temporal.task-queue:GREETING_TASK_QUEUE}")
    private String taskQueue;

    @Bean(destroyMethod = "shutdown")
    public WorkflowServiceStubs workflowServiceStubs() {
        WorkflowServiceStubsOptions options = WorkflowServiceStubsOptions.newBuilder()
                .setTarget(target)
                .build();
        return WorkflowServiceStubs.newInstance(options);
    }

    @Bean(destroyMethod = "close")
    public WorkflowClient workflowClient(WorkflowServiceStubs service) {
        return WorkflowClient.newInstance(service, WorkflowClient.newOptionsBuilder().setNamespace(namespace).build());
    }

    @Bean(destroyMethod = "shutdownNow")
    public WorkerFactory workerFactory(WorkflowClient client) {
        return WorkerFactory.newInstance(client);
    }

    @Bean
    public Worker greetingWorker(WorkerFactory factory, GreetingWorkflowImpl workflowImpl, GreetingActivitiesImpl activitiesImpl) {
        Worker worker = factory.newWorker(taskQueue);
        worker.registerWorkflowImplementationTypes(GreetingWorkflowImpl.class);
        worker.registerActivitiesImplementations(activitiesImpl);
        factory.start();
        return worker;
    }
}
