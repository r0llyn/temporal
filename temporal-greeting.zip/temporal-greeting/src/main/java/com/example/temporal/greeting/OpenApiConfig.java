package com.example.temporal.greeting;

import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    // springdoc-openapi-starter-webmvc-ui auto-configures Swagger UI at /swagger-ui.html
}
