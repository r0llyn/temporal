package com.example.temporal.greeting;

import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/greet", produces = MediaType.APPLICATION_JSON_VALUE)
public class GreetingController {

    private final WorkflowClient client;
    private final String taskQueue;

    public GreetingController(WorkflowClient client, @Value("${temporal.task-queue}") String taskQueue) {
        this.client = client;
        this.taskQueue = taskQueue;
    }

    @GetMapping
    public GreetingResponse greet(@RequestParam String name) {
        GreetingWorkflow workflow = client.newWorkflowStub(
                GreetingWorkflow.class,
                WorkflowOptions.newBuilder().setTaskQueue(taskQueue).build()
        );
        String result = workflow.greet(name);
        return new GreetingResponse(result);
    }

    public record GreetingResponse(String message) {}
}
