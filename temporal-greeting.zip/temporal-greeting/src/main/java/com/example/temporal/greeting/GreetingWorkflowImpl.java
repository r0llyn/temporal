package com.example.temporal.greeting;

import io.temporal.activity.ActivityOptions;
import io.temporal.workflow.Workflow;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
public class GreetingWorkflowImpl implements GreetingWorkflow {

    private final GreetingActivities activities = Workflow.newActivityStub(
            GreetingActivities.class,
            ActivityOptions.newBuilder()
                    .setStartToCloseTimeout(Duration.ofSeconds(10))
                    .setRetryOptions(io.temporal.common.RetryOptions.newBuilder()
                            .setInitialInterval(Duration.ofSeconds(1))
                            .setMaximumAttempts(3)
                            .build())
                    .build()
    );

    @Override
    public String greet(String name) {
        String normalized = activities.normalizeName(name);
        return activities.composeGreeting(normalized);
    }
}
