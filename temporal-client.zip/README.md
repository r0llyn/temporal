# temporal-client

Minimal Spring Boot app that proxies requests to `temporal-service`.

## Run
```bash
./mvnw spring-boot:run
# Client on :8080
```

## Example
```bash
curl -X POST "http://localhost:8080/client/report/start?type=SALES"
```
