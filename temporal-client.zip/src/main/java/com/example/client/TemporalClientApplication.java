package com.example.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemporalClientApplication {
    public static void main(String[] args) {
        SpringApplication.run(TemporalClientApplication.class, args);
    }
}
