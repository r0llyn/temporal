package com.example.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.util.Map;

@RestController
@RequestMapping("/client/report")
public class StartController {
  private final RestClient rest;

  public StartController(@Value("${service.baseUrl}") String baseUrl) {
    this.rest = RestClient.create(baseUrl);
  }

  @PostMapping("/start")
  public Map<String, String> start(@RequestParam(defaultValue="SALES") String type) {
    ResponseEntity<Map> resp = rest.post()
        .uri("/workflows/report/start")
        .body(Map.of("type", type))
        .retrieve()
        .toEntity(Map.class);
    return resp.getBody();
  }

  @PostMapping("/{workflowId}/cancel")
  public Map<String, String> cancel(@PathVariable String workflowId) {
    return rest.post()
        .uri("/workflows/report/{id}/cancel", workflowId)
        .retrieve()
        .body(Map.class);
  }

  @GetMapping("/{workflowId}/status")
  public Map<String, String> status(@PathVariable String workflowId) {
    return rest.get()
        .uri("/workflows/report/{id}/status", workflowId)
        .retrieve()
        .body(Map.class);
  }

  @GetMapping("/{workflowId}/result")
  public Map<String, String> result(@PathVariable String workflowId) {
    return rest.get()
        .uri("/workflows/report/{id}/result", workflowId)
        .retrieve()
        .body(Map.class);
  }
}
