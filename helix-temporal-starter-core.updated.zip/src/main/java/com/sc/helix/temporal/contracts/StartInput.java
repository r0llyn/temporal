package com.sc.helix.temporal.contracts;

import com.fasterxml.jackson.databind.JsonNode;

public record StartInput(String routine, JsonNode payload) {}
