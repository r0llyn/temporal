package com.sc.helix.temporal.activities.impl;

import com.sc.helix.temporal.activities.OrchestratedActivity;
import com.sc.helix.temporal.spi.RoutineHandler;
import java.util.Map;
import com.fasterxml.jackson.databind.JsonNode;

public class OrchestratedActivityImpl implements OrchestratedActivity {
  private final Map<String, RoutineHandler> registry;

  public OrchestratedActivityImpl(Map<String, RoutineHandler> registry) {
    this.registry = registry;
  }

  @Override
  public JsonNode execute(String routine, JsonNode payload) throws Exception {
    RoutineHandler handler = registry.get(routine);
    if (handler == null) {
      throw new IllegalArgumentException("Unknown routine: " + routine);
    }
    return handler.handle(payload);
  }
}
