package com.sc.helix.temporal.spi;

import com.fasterxml.jackson.databind.JsonNode;

@FunctionalInterface
public interface RoutineHandler {
  JsonNode handle(JsonNode payload) throws Exception;
}
