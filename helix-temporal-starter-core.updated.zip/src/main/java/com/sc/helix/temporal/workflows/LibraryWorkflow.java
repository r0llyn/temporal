package com.sc.helix.temporal.workflows;

import com.sc.helix.temporal.contracts.StartInput;
import com.fasterxml.jackson.databind.JsonNode;
import io.temporal.workflow.QueryMethod;
import io.temporal.workflow.SignalMethod;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface LibraryWorkflow {
  @WorkflowMethod(name = "LibraryWorkflow")
  JsonNode run(StartInput input);

  @SignalMethod
  void cancel();

  @QueryMethod
  String status();
}
