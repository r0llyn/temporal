package com.sc.helix.temporal.activities;

import com.fasterxml.jackson.databind.JsonNode;
import io.temporal.activity.ActivityMethod;

public interface OrchestratedActivity {
  @ActivityMethod
  JsonNode execute(String routine, JsonNode payload) throws Exception;
}
