
package com.sc.helix.temporal.autoconfigure;

import com.sc.helix.temporal.activities.impl.OrchestratedActivityImpl;
import com.sc.helix.temporal.spi.Routine;
import com.sc.helix.temporal.spi.RoutineHandler;
import com.sc.helix.temporal.spi.RoutineOptions;
import com.sc.helix.temporal.workflows.LibraryWorkflow;
import com.sc.helix.temporal.workflows.impl.LibraryWorkflowImpl;
import io.temporal.client.WorkflowClient;
import io.temporal.common.RetryOptions;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@AutoConfiguration
@ConditionalOnClass({WorkflowClient.class, WorkerFactory.class})
public class TemporalLibraryAutoConfig {

  @Bean(destroyMethod = "shutdown")
  @ConditionalOnMissingBean
  public WorkerFactory workerFactory(WorkflowClient client) {
    return WorkerFactory.newInstance(client);
  }

  /**
   * Build the routine registry from RoutineHandler beans.
   * Key selection priority: @Routine(value) on bean class -> bean name.
   */
  @Bean
  @ConditionalOnMissingBean(name = "routineRegistry")
  public Map<String, RoutineHandler> routineRegistry(ApplicationContext ctx, ObjectProvider<RoutineHandler> handlers) {
    Map<String, RoutineHandler> map = new HashMap<>();
    handlers.forEach(h -> {
      Routine ann = h.getClass().getAnnotation(Routine.class);
      String key = (ann != null && !ann.value().isBlank()) ? ann.value() : ctx.getBeanNamesForType(h.getClass())[0];
      map.put(key, h);
    });
    return Map.copyOf(map);
  }

  /**
   * Optional per-routine RetryOptions constructed from @RoutineOptions on the handler type.
   * Users can still override by providing their own Map<String, RetryOptions> bean.
   */
  @Bean
  @ConditionalOnMissingBean(name = "retryByRoutine")
  public Map<String, RetryOptions> retryByRoutine(ApplicationContext ctx, ObjectProvider<RoutineHandler> handlers) {
    Map<String, RetryOptions> map = new HashMap<>();
    handlers.forEach(h -> {
      Routine ann = h.getClass().getAnnotation(Routine.class);
      RoutineOptions opts = h.getClass().getAnnotation(RoutineOptions.class);
      if (ann != null && opts != null) {
        RetryOptions ro = RetryOptions.newBuilder()
            .setMaximumAttempts(opts.maximumAttempts())
            .setInitialInterval(Duration.ofSeconds(opts.initialIntervalSeconds()))
            .setBackoffCoefficient(opts.backoffCoefficient())
            .setMaximumInterval(Duration.ofSeconds(opts.maximumIntervalSeconds()))
            .build();
        map.put(ann.value(), ro);
      }
    });
    return Map.copyOf(map);
  }

  /**
   * Start a Worker and register the library's workflow & activity.
   * Enabled when property 'temporal.task-queue' is present.
   */
  @Bean(initMethod = "start", destroyMethod = "shutdown")
  @ConditionalOnProperty(prefix = "temporal", name = "task-queue")
  public WorkerStarter workerStarter(WorkerFactory factory,
                                     WorkflowClient client,
                                     @Value("${temporal.task-queue}") String taskQueue,
                                     Map<String, RoutineHandler> routineRegistry,
                                     ObjectProvider<Map<String, RetryOptions>> retryByRoutineProvider) {
    Worker worker = factory.newWorker(taskQueue);

    Map<String, RetryOptions> retryByRoutine = Optional.ofNullable(retryByRoutineProvider.getIfAvailable())
        .orElseGet(Map::of);

    // Register workflow with constructor-provided retry map
    worker.registerWorkflowImplementationFactory(
        LibraryWorkflow.class,
        () -> new LibraryWorkflowImpl(retryByRoutine)
    );

    // Register activity with discovered registry
    worker.registerActivitiesImplementations(new OrchestratedActivityImpl(routineRegistry));

    return new WorkerStarter(factory);
  }

  public static final class WorkerStarter implements AutoCloseable {
    private final WorkerFactory factory;
    public WorkerStarter(WorkerFactory factory) { this.factory = factory; }
    public void start() { factory.start(); }
    public void shutdown() { factory.shutdown(); }
    @Override public void close() { shutdown(); }
  }
}
