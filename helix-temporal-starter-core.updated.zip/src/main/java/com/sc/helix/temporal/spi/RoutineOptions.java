package com.sc.helix.temporal.spi;

import java.lang.annotation.*;
import java.time.temporal.ChronoUnit;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface RoutineOptions {
  int maxAttempts() default 3;
  long initialInterval() default 1L;
  ChronoUnit initialUnit() default ChronoUnit.SECONDS;
  long maximumInterval() default 30L;
  ChronoUnit maximumUnit() default ChronoUnit.SECONDS;
  double backoffCoefficient() default 2.0;
}
