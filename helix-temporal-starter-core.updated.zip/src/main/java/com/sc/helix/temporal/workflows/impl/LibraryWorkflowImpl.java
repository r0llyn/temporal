
package com.sc.helix.temporal.workflows.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.sc.helix.temporal.activities.OrchestratedActivity;
import com.sc.helix.temporal.contracts.StartInput;
import com.sc.helix.temporal.workflows.LibraryWorkflow;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.workflow.Workflow;

import java.time.Duration;
import java.util.Map;

public class LibraryWorkflowImpl implements LibraryWorkflow {

  private volatile boolean cancelled = false;
  private volatile String status = "PENDING";
  private final Map<String, RetryOptions> retryOptionsByRoutine;

  public LibraryWorkflowImpl(Map<String, RetryOptions> retryOptionsByRoutine) {
    this.retryOptionsByRoutine = retryOptionsByRoutine;
  }

  @Override
  public JsonNode run(StartInput input) {
    status = "RUNNING";
    if (cancelled) { status = "CANCELLED"; return null; }

    RetryOptions ro = retryOptionsByRoutine.getOrDefault(
        input.routine(),
        RetryOptions.newBuilder()
            .setMaximumAttempts(3)
            .setInitialInterval(Duration.ofSeconds(1))
            .setBackoffCoefficient(2.0)
            .setMaximumInterval(Duration.ofSeconds(30))
            .build()
    );

    OrchestratedActivity activity = Workflow.newActivityStub(
        OrchestratedActivity.class,
        ActivityOptions.newBuilder()
            .setRetryOptions(ro)
            .setStartToCloseTimeout(Duration.ofMinutes(10))
            .build()
    );

    try {
      JsonNode result = activity.execute(input.routine(), input.payload());
      status = cancelled ? "CANCELLED" : "COMPLETED";
      return result;
    } catch (Exception e) {
      status = "FAILED";
      throw Workflow.wrap(e);
    }
  }

  @Override
  public void cancel() { this.cancelled = true; }

  @Override
  public String status() { return status; }
}
