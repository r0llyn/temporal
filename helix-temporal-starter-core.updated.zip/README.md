# helix-temporal-starter-core

**groupId:** `com.sc`  
**artifactId:** `helix-temporal-starter-core`

Starter that:
- runs a Temporal worker (optional Build ID versioning via properties),
- exposes a single workflow type `LibraryWorkflow`,
- routes to `@Routine` handlers,
- supports per‑routine retry via `@RoutineOptions`.

## Properties
```yaml
temporal:
  target: localhost:7233
  namespace: default
  taskQueue: LIBRARY_TASK_QUEUE
  buildId: v1.0.0
  versioning:
    enabled: true
```
