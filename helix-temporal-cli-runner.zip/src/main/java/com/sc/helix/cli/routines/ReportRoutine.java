package com.sc.helix.cli.routines;

import com.sc.helix.temporal.spi.Routine;
import com.sc. helix.temporal.spi.RoutineHandler;
import com.sc.helix.temporal.spi.RoutineOptions;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.TextNode;
import org.springframework.stereotype.Component;

@Routine("report")
@RoutineOptions(maxAttempts = 3, initialInterval = 1, maximumInterval = 10, backoffCoefficient = 2.0)
@Component
public class ReportRoutine implements RoutineHandler {
  @Override
  public JsonNode handle(JsonNode payload) {
    String type = payload.path("type").asText("DEFAULT");
    return TextNode.valueOf("Generated report: " + type);
  }
}
