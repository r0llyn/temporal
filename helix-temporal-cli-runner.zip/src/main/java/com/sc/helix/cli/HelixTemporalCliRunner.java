package com.sc.helix.cli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import com.sc.helix.temporal.contracts.StartInput;
import com.sc.helix.temporal.workflows.LibraryWorkflow;

import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;

import java.util.UUID;

@SpringBootApplication
public class HelixTemporalCliRunner implements CommandLineRunner {

  private final WorkflowClient client;
  private final ObjectMapper mapper;

  @Value("${temporal.taskQueue}")
  String taskQueue;

  public HelixTemporalCliRunner(WorkflowClient client, ObjectMapper mapper) {
    this.client = client;
    this.mapper = mapper;
  }

  public static void main(String[] args) {
    System.exit(SpringApplication.exit(SpringApplication.run(HelixTemporalCliRunner.class, args)));
  }

  @Override
  public void run(String... args) throws Exception {
    String type = (args.length > 0 ? args[0] : "SALES");

    ObjectNode payload = mapper.createObjectNode();
    payload.put("type", type);

    LibraryWorkflow stub = client.newWorkflowStub(
        LibraryWorkflow.class,
        WorkflowOptions.newBuilder()
            .setTaskQueue(taskQueue)
            .setWorkflowId("cli-" + UUID.randomUUID())
            .build());

    // block until workflow completes, print result, exit
    String result = client.newUntypedWorkflowStub(stub)
        .execute(String.class, new StartInput("report", payload));

    System.out.println("Workflow completed. Result: " + result);
  }
}
