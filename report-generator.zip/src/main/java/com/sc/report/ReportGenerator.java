package com.sc.report;

public class ReportGenerator {
    public static void main(String[] args) {
        System.out.println("Report generated");
    }
}
