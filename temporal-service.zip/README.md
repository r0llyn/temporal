# temporal-service

Spring Boot app that exposes REST endpoints to start/signal/query Temporal workflows **and** runs the Temporal Worker.

## Run Temporal Server (dev)
```bash
docker compose up -d
# Web UI: http://localhost:8233
```

## Run the service
```bash
./mvnw spring-boot:run
# Service on :9090
```

## Example
```bash
curl -X POST "http://localhost:9090/workflows/report/start" -H "Content-Type: application/json" -d '{"type":"SALES"}'
```
