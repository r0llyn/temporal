package com.example.workflow.impl;

import com.example.workflow.ReportActivities;

public class ReportActivitiesImpl implements ReportActivities {
  @Override
  public String generateReport(String type) {
    // Simulate work / external I/O
    try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
    return "Generated report for: " + type;
  }
}
