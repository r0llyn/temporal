package com.example.workflow.impl;

import com.example.workflow.ReportActivities;
import com.example.workflow.ReportWorkflow;
import io.temporal.activity.ActivityOptions;
import io.temporal.workflow.Workflow;
import java.time.Duration;

public class ReportWorkflowImpl implements ReportWorkflow {

  private final ReportActivities activities =
      Workflow.newActivityStub(
          ReportActivities.class,
          ActivityOptions.newBuilder()
              .setStartToCloseTimeout(Duration.ofMinutes(5))
              .build());

  private volatile String status = "PENDING";
  private volatile boolean cancelled = false;

  @Override
  public String run(String reportType) {
    status = "RUNNING";
    if (cancelled) {
      status = "CANCELLED";
      return "Cancelled before start";
    }
    String result = activities.generateReport(reportType);
    status = cancelled ? "CANCELLED" : "COMPLETED";
    return result;
  }

  @Override
  public void cancel() { this.cancelled = true; }

  @Override
  public String status() { return status; }
}
