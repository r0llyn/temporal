package com.example.workflow;

import io.temporal.workflow.QueryMethod;
import io.temporal.workflow.SignalMethod;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface ReportWorkflow {

  @WorkflowMethod
  String run(String reportType);

  @SignalMethod
  void cancel();

  @QueryMethod
  String status();
}
