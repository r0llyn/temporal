package com.example.workflow;

import io.temporal.activity.ActivityMethod;

public interface ReportActivities {
  @ActivityMethod
  String generateReport(String type);
}
