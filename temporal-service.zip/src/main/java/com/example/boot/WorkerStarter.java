package com.example.boot;

import io.temporal.worker.WorkerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class WorkerStarter implements CommandLineRunner {
  private final WorkerFactory factory;
  public WorkerStarter(WorkerFactory factory) { this.factory = factory; }
  @Override
  public void run(String... args) {
    factory.start();
  }
}
