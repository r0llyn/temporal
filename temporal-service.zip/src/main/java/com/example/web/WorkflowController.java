package com.example.web;

import com.example.workflow.ReportWorkflow;
import io.temporal.api.workflow.v1.WorkflowExecution;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import io.temporal.client.WorkflowStub;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/workflows/report")
public class WorkflowController {

  private final WorkflowClient client;

  @Value("${temporal.taskQueue}")
  private String taskQueue;

  public WorkflowController(WorkflowClient client) { this.client = client; }

  @PostMapping("/start")
  public Map<String, String> start(@RequestBody Map<String, String> body) {
    String type = body.getOrDefault("type", "DEFAULT");
    String workflowId = UUID.randomUUID().toString();

    ReportWorkflow stub = client.newWorkflowStub(
        ReportWorkflow.class,
        WorkflowOptions.newBuilder()
            .setTaskQueue(taskQueue)
            .setWorkflowId(workflowId)
            .build());

    WorkflowExecution exec = WorkflowClient.start(stub::run, type);

    return Map.of("workflowId", exec.getWorkflowId(), "runId", exec.getRunId());
  }

  @PostMapping("/{workflowId}/cancel")
  public Map<String, String> cancel(@PathVariable String workflowId) {
    ReportWorkflow stub = client.newWorkflowStub(ReportWorkflow.class, workflowId);
    stub.cancel();
    return Map.of("status", "SIGNAL_SENT");
  }

  @GetMapping("/{workflowId}/status")
  public Map<String, String> status(@PathVariable String workflowId) {
    ReportWorkflow stub = client.newWorkflowStub(ReportWorkflow.class, workflowId);
    String status = stub.status();
    return Map.of("status", status);
  }

  @GetMapping("/{workflowId}/result")
  public Map<String, String> result(@PathVariable String workflowId) {
    WorkflowStub untyped = client.newUntypedWorkflowStub(workflowId);
    String result = untyped.getResult(String.class);
    return Map.of("result", result);
  }
}
