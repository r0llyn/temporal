package com.sc.temporal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelixTemporalSagaApplicationTests {

	@Test
	void contextLoads() {
	}

}
