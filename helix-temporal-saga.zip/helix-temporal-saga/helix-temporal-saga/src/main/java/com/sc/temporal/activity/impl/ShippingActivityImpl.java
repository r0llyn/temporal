package com.sc.temporal.activity.impl;

import com.sc.temporal.activity.ShippingActivity;

public class ShippingActivityImpl implements ShippingActivity {

  @Override
  public String arrangeShipping(String userId, String address) {
    System.out.println("Arranging shipping for user " + userId + " to address " + address);
    return "SHIP-" + System.currentTimeMillis();
  }
}