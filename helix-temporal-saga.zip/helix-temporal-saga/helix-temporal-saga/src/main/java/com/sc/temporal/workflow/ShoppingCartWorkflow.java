package com.sc.temporal.workflow;

import com.sc.temporal.dto.CheckoutRequest;
import com.sc.temporal.dto.CheckoutResult;
import io.temporal.workflow.QueryMethod;
import io.temporal.workflow.SignalMethod;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface ShoppingCartWorkflow {

  @WorkflowMethod
  CheckoutResult checkout(CheckoutRequest req);

  @QueryMethod
  String getStatus();

  @SignalMethod
  void cancel();
}
