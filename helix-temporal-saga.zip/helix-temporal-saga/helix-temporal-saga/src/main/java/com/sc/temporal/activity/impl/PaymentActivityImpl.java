package com.sc.temporal.activity.impl;

import com.sc.temporal.activity.PaymentActivity;

public class PaymentActivityImpl implements PaymentActivity {

  @Override
  public boolean processPayment(String userId, double amount) {
    System.out.println("Processing payment of $" + amount + " for user " + userId);
    return true;
  }

  @Override
  public void refundPayment(String userId, double amount) {
    System.out.println("Refunding $" + amount + " to user " + userId);
  }
}
