package com.sc.temporal.activity.impl;

import com.sc.temporal.activity.InventoryActivity;
import java.util.List;

public class InventoryActivityImpl implements InventoryActivity {

  @Override
  public boolean reserveItems(String userId, List<String> itemIds) {
    System.out.println("Reserving items " + itemIds + " for user " + userId);
    return true;
  }

  @Override
  public void releaseItems(String userId, List<String> itemIds) {
    System.out.println("Releasing items " + itemIds + " for user " + userId);
  }
}
