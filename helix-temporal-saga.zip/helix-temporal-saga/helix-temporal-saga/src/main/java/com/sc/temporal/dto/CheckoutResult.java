package com.sc.temporal.dto;

public class CheckoutResult {
  private boolean success;
  private String orderId;
  private String message;

  public CheckoutResult() {}

  public CheckoutResult(boolean success, String orderId, String message) {
    this.success = success;
    this.orderId = orderId;
    this.message = message;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  @Override
  public String toString() {
    return "CheckoutResult{"
        + "success="
        + success
        + ", orderId='"
        + orderId
        + '\''
        + ", message='"
        + message
        + '\''
        + '}';
  }
}
