package com.sc.temporal.activity;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface PaymentActivity {
  boolean processPayment(String userId, double amount);
  void refundPayment(String userId, double amount);
}