package com.sc.temporal.activity;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface ShippingActivity {
  String arrangeShipping(String userId, String address);
}