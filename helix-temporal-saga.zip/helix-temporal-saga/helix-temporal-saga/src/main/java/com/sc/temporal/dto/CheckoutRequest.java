package com.sc.temporal.dto;

import java.util.List;

public class CheckoutRequest {
  private String userId;
  private List<String> itemIds;
  private double totalAmount;
  private String shippingAddress;

  public CheckoutRequest() {}

  public CheckoutRequest(
      String userId, List<String> itemIds, double totalAmount, String shippingAddress) {
    this.userId = userId;
    this.itemIds = itemIds;
    this.totalAmount = totalAmount;
    this.shippingAddress = shippingAddress;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public List<String> getItemIds() {
    return itemIds;
  }

  public void setItemIds(List<String> itemIds) {
    this.itemIds = itemIds;
  }

  public double getTotalAmount() {
    return totalAmount;
  }

  public void setTotalAmount(double totalAmount) {
    this.totalAmount = totalAmount;
  }

  public String getShippingAddress() {
    return shippingAddress;
  }

  public void setShippingAddress(String shippingAddress) {
    this.shippingAddress = shippingAddress;
  }

  @Override
  public String toString() {
    return "CheckoutRequest{"
        + "userId='"
        + userId
        + '\''
        + ", itemIds="
        + itemIds
        + ", totalAmount="
        + totalAmount
        + ", shippingAddress='"
        + shippingAddress
        + '\''
        + '}';
  }
}
