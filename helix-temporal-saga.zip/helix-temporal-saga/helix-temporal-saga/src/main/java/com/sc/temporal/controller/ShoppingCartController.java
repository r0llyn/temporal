package com.sc.temporal.controller;

import com.sc.temporal.config.TemporalConfig;
import com.sc.temporal.dto.CheckoutRequest;
import com.sc.temporal.workflow.ShoppingCartWorkflow;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
@Tag(name = "Shopping Cart Workflow API")
public class ShoppingCartController {

  private final WorkflowClient client;

  public ShoppingCartController(WorkflowClient client) {
    this.client = client;
  }

  @PostMapping("/checkout")
  @Operation(summary = "Checkout a shopping cart workflow")
  public String checkout(@RequestParam String orderId) {
    ShoppingCartWorkflow workflow =
        client.newWorkflowStub(
            ShoppingCartWorkflow.class,
            WorkflowOptions.newBuilder()
                .setTaskQueue(TemporalConfig.TASK_QUEUE)
                .setWorkflowId("cart-" + orderId)
                .build());

    CheckoutRequest request = new CheckoutRequest(
            "user-123",
            List.of("item-101", "item-202"),
            1599.50,
            "123 Main Street, Cebu City"
    );

    WorkflowClient.start(workflow::checkout, request);
    return "Checkout started for orderId=" + orderId;
  }

  @GetMapping("/status/{orderId}")
  @Operation(summary = "Get workflow result for given orderId")
  public String getStatus(@PathVariable String orderId) {
    ShoppingCartWorkflow workflow =
        client.newWorkflowStub(
            ShoppingCartWorkflow.class,
            WorkflowOptions.newBuilder()
                .setTaskQueue(TemporalConfig.TASK_QUEUE)
                .setWorkflowId("cart-" + orderId)
                .build());

    return workflow.getStatus();
  }
}
