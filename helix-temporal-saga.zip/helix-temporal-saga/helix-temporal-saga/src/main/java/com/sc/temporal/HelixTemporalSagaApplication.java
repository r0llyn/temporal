package com.sc.temporal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelixTemporalSagaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelixTemporalSagaApplication.class, args);
	}

}
