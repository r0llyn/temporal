package com.sc.temporal.workflow;

import com.sc.temporal.activity.InventoryActivity;
import com.sc.temporal.activity.PaymentActivity;
import com.sc.temporal.activity.ShippingActivity;
import com.sc.temporal.dto.CheckoutRequest;
import com.sc.temporal.dto.CheckoutResult;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.workflow.Workflow;

import java.time.Duration;

public class ShoppingCartWorkflowImpl implements ShoppingCartWorkflow{

    private final InventoryActivity inventory;
    private final PaymentActivity payment;
    private final ShippingActivity shipping;

    private volatile String status = "CREATED";
    private volatile boolean cancelled = false;

    public ShoppingCartWorkflowImpl() {
        RetryOptions retry =
                RetryOptions.newBuilder()
                        .setInitialInterval(Duration.ofSeconds(1))
                        .setMaximumInterval(Duration.ofSeconds(10))
                        .setMaximumAttempts(3)
                        .build();

        ActivityOptions opts =
                ActivityOptions.newBuilder()
                        .setStartToCloseTimeout(Duration.ofSeconds(10))
                        .setRetryOptions(retry)
                        .build();

        this.inventory = Workflow.newActivityStub(InventoryActivity.class, opts);
        this.payment   = Workflow.newActivityStub(PaymentActivity.class,   opts);
        this.shipping  = Workflow.newActivityStub(ShippingActivity.class,  opts);
    }

    @Override
    public CheckoutResult checkout(CheckoutRequest req) {
        boolean reserved = false;
        boolean paid = false;
        String shipmentId = null;

        try {
            // 1) Reserve inventory
            status = "RESERVING_INVENTORY";
            reserved = inventory.reserveItems(req.getUserId(), req.getItemIds());
            ensureNotCancelled();

            // 2) Process payment
            status = "PROCESSING_PAYMENT";
            paid = payment.processPayment(req.getUserId(), req.getTotalAmount());
            ensureNotCancelled();

            // 3) Arrange shipping
            status = "ARRANGING_SHIPPING";
            shipmentId = shipping.arrangeShipping(req.getUserId(), req.getShippingAddress());
            ensureNotCancelled();

            status = "COMPLETED";
            return new CheckoutResult(true, shipmentId, "Order completed: " + shipmentId);

        } catch (Exception e) {
            status = "FAILED:" + e.getMessage();

            try { if (paid) payment.refundPayment(req.getUserId(), req.getTotalAmount()); } catch (Throwable ignore) {}
            try { if (reserved) inventory.releaseItems(req.getUserId(), req.getItemIds()); } catch (Throwable ignore) {}

            throw e;
        }
    }

    @Override
    public String getStatus() { return status; }

    @Override
    public void cancel() { cancelled = true; status = "CANCELLED"; }

    private void ensureNotCancelled() {
        if (cancelled) throw new RuntimeException("cancelled");
    }
}
