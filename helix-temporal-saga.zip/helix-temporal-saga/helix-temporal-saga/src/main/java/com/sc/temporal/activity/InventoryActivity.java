package com.sc.temporal.activity;

import io.temporal.activity.ActivityInterface;

import java.util.List;

@ActivityInterface
public interface InventoryActivity {
  boolean reserveItems(String userId, List<String> itemIds);
  void releaseItems(String userId, List<String> itemIds);
}