package com.sc.temporal.config;

import com.sc.temporal.activity.impl.InventoryActivityImpl;
import com.sc.temporal.activity.impl.PaymentActivityImpl;
import com.sc.temporal.activity.impl.ShippingActivityImpl;
import com.sc.temporal.workflow.ShoppingCartWorkflowImpl;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowClientOptions;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.serviceclient.WorkflowServiceStubsOptions;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TemporalConfig {

  public static final String TASK_QUEUE = "SHOPPING_CART_TASK_QUEUE";

  @Bean(destroyMethod = "shutdown")
  public WorkflowServiceStubs service(
      @Value("${temporal.server.target:127.0.0.1:7233}") String address) {
    return WorkflowServiceStubs.newServiceStubs(
        WorkflowServiceStubsOptions.newBuilder().setTarget(address).build());
  }

  @Bean
  public WorkflowClient client(
      WorkflowServiceStubs service,
      @Value("${temporal.server.namespace:default}") String namespace) {
    return WorkflowClient.newInstance(
        service, WorkflowClientOptions.newBuilder().setNamespace(namespace).build());
  }

  @Bean(initMethod = "start", destroyMethod = "shutdownNow")
  public WorkerFactory workerFactory(WorkflowClient client) {
    WorkerFactory factory = WorkerFactory.newInstance(client);

    Worker worker = factory.newWorker(TASK_QUEUE);
    worker.registerWorkflowImplementationTypes(ShoppingCartWorkflowImpl.class);
    worker.registerActivitiesImplementations(
        new InventoryActivityImpl(), new PaymentActivityImpl(), new ShippingActivityImpl());

    return factory;
  }
}
