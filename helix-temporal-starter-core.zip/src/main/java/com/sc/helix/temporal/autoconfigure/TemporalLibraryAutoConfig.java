package com.sc.helix.temporal.autoconfigure;

import com.sc.helix.temporal.activities.impl.OrchestratedActivityImpl;
import com.sc.helix.temporal.spi.Routine;
import com.sc.helix.temporal.spi.RoutineHandler;
import com.sc.helix.temporal.spi.RoutineOptions;
import com.sc.helix.temporal.workflows.impl.LibraryWorkflowImpl;
import com.sc.helix.temporal.workflows.LibraryWorkflow;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowClientOptions;
import io.temporal.common.RetryOptions;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.serviceclient.WorkflowServiceStubsOptions;
import io.temporal.worker.Worker;
import io.temporal.worker.WorkerFactory;
import io.temporal.worker.WorkerOptions;
import io.temporal.worker.WorkflowImplementationOptions;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.context.annotation.Bean;

import java.time.Duration;
import java.util.Map;
import java.util.stream.Collectors;

@AutoConfiguration
public class TemporalLibraryAutoConfig {

  @Bean
  public WorkflowServiceStubs serviceStubs(@Value("${temporal.target:localhost:7233}") String target) {
    return WorkflowServiceStubs.newInstance(
        WorkflowServiceStubsOptions.newBuilder().setTarget(target).build());
  }

  @Bean
  public WorkflowClient workflowClient(
      WorkflowServiceStubs service,
      @Value("${temporal.namespace:default}") String namespace) {
    return WorkflowClient.newInstance(service, WorkflowClientOptions.newBuilder()
        .setNamespace(namespace).build());
  }

  @Bean
  public WorkerFactory workerFactory(WorkflowClient client) {
    return WorkerFactory.newInstance(client);
  }

  @Bean
  public Worker worker(
      WorkerFactory factory,
      @Value("${temporal.taskQueue:LIBRARY_TASK_QUEUE}") String taskQueue,
      ObjectProvider<RoutineHandler> handlersProvider,
      @Value("${temporal.buildId:}") String buildId,
      @Value("${temporal.versioning.enabled:false}") boolean useBuildIdForVersioning) {

    Map<String, RoutineHandler> registry =
        handlersProvider.stream().collect(Collectors.toMap(
            h -> h.getClass().getAnnotation(Routine.class).value(),
            h -> h));

    WorkerOptions.Builder wopts = WorkerOptions.newBuilder();
    if (!buildId.isBlank()) {
      wopts.setBuildId(buildId).setUseBuildIdForVersioning(useBuildIdForVersioning);
    }

    Map<String, RetryOptions> retryByRoutine =
        handlersProvider.stream().collect(Collectors.toMap(
            h -> h.getClass().getAnnotation(Routine.class).value(),
            h -> {
              RoutineOptions ann = h.getClass().getAnnotation(RoutineOptions.class);
              if (ann == null) {
                return RetryOptions.newBuilder()
                    .setMaximumAttempts(3)
                    .setInitialInterval(Duration.ofSeconds(1))
                    .setBackoffCoefficient(2.0)
                    .setMaximumInterval(Duration.ofSeconds(30))
                    .build();
              }
              return RetryOptions.newBuilder()
                  .setMaximumAttempts(ann.maxAttempts())
                  .setInitialInterval(Duration.of(ann.initialInterval(), ann.initialUnit()))
                  .setBackoffCoefficient(ann.backoffCoefficient())
                  .setMaximumInterval(Duration.of(ann.maximumInterval(), ann.maximumUnit()))
                  .build();
            }
        ));

    Worker worker = factory.newWorker(taskQueue, wopts.build());

    WorkflowImplementationOptions wio = WorkflowImplementationOptions.newBuilder()
        .setWorkflowFactory((workflowType) -> new LibraryWorkflowImpl(retryByRoutine))
        .build();

    worker.registerWorkflowImplementationTypes(wio, LibraryWorkflowImpl.class);
    worker.registerActivitiesImplementations(new OrchestratedActivityImpl(registry));

    factory.start();
    return worker;
  }
}
