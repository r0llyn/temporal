# temporal-example1 (Spring Boot + Temporal)

Minimal app that exposes `GET /greet/{name}` and returns `Hello {name}`
by running a Temporal workflow.

## Prereqs
- Temporal Server running locally:
  ```bash
  docker run --rm -p 7233:7233 temporalio/auto-setup:latest
  ```

## Run
```bash
mvn spring-boot:run
# then visit:
curl http://localhost:8080/greet/John
# -> Hello John
```

## Config (src/main/resources/application.yml)
```yaml
temporal:
  target: localhost:7233
  namespace: default
  taskQueue: GREETING_TASK_QUEUE
```
