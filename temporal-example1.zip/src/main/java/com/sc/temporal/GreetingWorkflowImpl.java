package com.sc.temporal;

import io.temporal.workflow.Workflow;

public class GreetingWorkflowImpl implements GreetingWorkflow {
    @Override
    public String getGreeting(String name) {
        Workflow.getLogger(GreetingWorkflowImpl.class).info("Generating greeting for {}", name);
        return "Hello " + name;
    }
}
